/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: jejak_bali
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `aktivitas`
--

DROP TABLE IF EXISTS `aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aktivitas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aktivitas_nama_unique` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aktivitas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `aktivitas` WRITE;
/*!40000 ALTER TABLE `aktivitas` DISABLE KEYS */;
INSERT INTO `aktivitas` VALUES
(1,'Diving','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,'Fotografi','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,'Kuliner ikan bakar','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,'Matahari terbit','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,'Snorkeling','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(6,'Beri makan koi','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(7,'Pemandian suci','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(8,'Trekking ringan','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(9,'Ibadah','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(10,'Meditasi','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(11,'Trekking','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(12,'Pemandian air panas','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(13,'Perahu nelayan','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(14,'Tontonan lumba-lumba','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(15,'Berenang','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(16,'Wisata kebun','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(17,'Bersepeda','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(18,'Edukasi subak','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(19,'Kuliner','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(20,'Trekking sawah','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(21,'Kuliner desa','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(22,'Trekking gunung','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(23,'Tenun & kerajinan','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(24,'Renang','2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `aktivitas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmark` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_bookmark_user_destinasi` (`user_id`,`destinasi_id`),
  KEY `bookmark_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `bookmark_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookmark_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmark`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bookmark` WRITE;
/*!40000 ALTER TABLE `bookmark` DISABLE KEYS */;
INSERT INTO `bookmark` VALUES
(1,1,1,'2026-11-18 16:38:14','2026-11-18 16:38:14');
/*!40000 ALTER TABLE `bookmark` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `budaya`
--

DROP TABLE IF EXISTS `budaya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `budaya` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `ringkas` text NOT NULL,
  `detail` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `budaya_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budaya`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `budaya` WRITE;
/*!40000 ALTER TABLE `budaya` DISABLE KEYS */;
INSERT INTO `budaya` VALUES
(1,'busana-pura','Busana Masuk Pura','Kain saput dan syal untuk wanita, kain panjang untuk pria.','Kain saput dipakai di pinggang dan syal menutup bahu. Hindari celana pendek dan rok mini di area suci. Jika tidak membawa, biasanya dapat dipinjam di pintu masuk pura.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,'canang-sari','Canang Sari','Persembahan kecil dari janur dan bunga di jalanan dan depan rumah.','Jangan menginjak canang yang tersebar di jalanan. Jika ingin memotret, minta izin terlebih dahulu kepada pemilik rumah atau penjaga area.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,'nyepi','Hari Nyepi','Hari suci Tahun Baru Saka, seluruh aktivitas dihentikan 24 jam.','Selama Catur Brata Penyepian: api mati, lampu redup, tidak keluar rumah, tidak bekerja, dan tidak bersuka ria. Wisatawan di hotel juga diharapkan mematuhi.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,'basa-bali','Frasa Bahasa Bali Dasar','Kata sederhana untuk menunjukkan hormat kepada warga lokal.','Om Swastiastu (salam hormat), Matur Suksma (terima kasih), Bli (sapaan laki-laki), Mbok (sapaan perempuan).','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,'adat-laut','Adat Laut & Nelayan','Hormati laut dan kehidupan nelayan di pesisir Bali.','Jangan membuang sampah ke laut dan jangan menyentuh terumbu karang saat berenang. Jika akan naik perahu, ikuti arahan nelayan lokal.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(6,'pantang-larang-desa','Pantang Larang Desa','Beberapa area desa memiliki larangan khusus pada waktu tertentu.','Perhatikan papan pengumuman di pintu desa. Jika ada area yang dilarang untuk difoto, hargai dan jangan memaksa mengambil gambar.','2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `budaya` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi`
--

DROP TABLE IF EXISTS `destinasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `wilayah_id` bigint(20) unsigned NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL DEFAULT '',
  `deskripsi` text NOT NULL,
  `waktu_terbaik` varchar(255) NOT NULL DEFAULT '',
  `jam_buka` varchar(255) NOT NULL DEFAULT '',
  `tarif` varchar(255) NOT NULL DEFAULT '',
  `cara_masuk` text NOT NULL,
  `etika` text NOT NULL,
  `whatsapp` varchar(255) DEFAULT NULL,
  `kontak` varchar(255) NOT NULL DEFAULT '-',
  `rating_awal` decimal(3,1) NOT NULL DEFAULT 4.5,
  `gambar` varchar(255) NOT NULL DEFAULT '',
  `is_unggulan` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('draft','aktif') NOT NULL DEFAULT 'aktif',
  `latitude` decimal(10,7) NOT NULL DEFAULT 0.0000000,
  `longitude` decimal(10,7) NOT NULL DEFAULT 0.0000000,
  `maps_url` varchar(255) NOT NULL DEFAULT '',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `destinasi_slug_unique` (`slug`),
  KEY `destinasi_wilayah_id_foreign` (`wilayah_id`),
  KEY `destinasi_user_id_foreign` (`user_id`),
  FULLTEXT KEY `destinasi_nama_deskripsi_fulltext` (`nama`,`deskripsi`),
  CONSTRAINT `destinasi_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `destinasi_wilayah_id_foreign` FOREIGN KEY (`wilayah_id`) REFERENCES `wilayah` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi` WRITE;
/*!40000 ALTER TABLE `destinasi` DISABLE KEYS */;
INSERT INTO `destinasi` VALUES
(1,'amed-pantai',1,'Pantai Amed','Pantai & Nelayan','Rangkaian desa nelayan berpasir hitam dengan terumbu karang yang paling sehat di Bali.','April – November (musim kemarau)','06:00 – 18:00','Gratis (donasi sukarela)','Kendaraan pribadi dari Amlapura, sekitar 1 jam.','Jangan menyentuh atau berdiri di atas terumbu karang. Hormati nelayan lokal yang sedang bekerja dan minta izin sebelum memotret perahu atau warga.','6281234567890','0812-3456-7890',4.8,'assets/images/amed.jpg',1,'aktif',-8.3499000,115.6568000,'https://maps.google.com/?q=-8.3499,115.6568',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,'tirta-gangga',1,'Taman Tirta Gangga','Taman Air Kerajaan','Taman air kerajaan 1948 dengan kolam koi, patung dewa, dan batu pijakan di atas air.','Pukul 07.00 – 09.00, sebelum rombongan tiba','07:00 – 18:00','Rp 50.000 (dewasa)','Kendaraan pribadi, area parkir tersedia.','Gunakan kain saput saat memasuki area suci dan pemandian. Jangan merokok di sekitar kolam suci dan jangan berdiri di atas patung.','6281322334455','0813-2233-4455',4.7,'assets/images/tirta-gangga.jpg',1,'aktif',-8.4116000,115.5873000,'https://maps.google.com/?q=-8.4116,115.5873',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,'pura-lempuyang',1,'Pura Lempuyang','Pura','Pura Sad Kahyangan berusia ribuan tahun dengan candi bentar yang membingkai Gunung Agung.','Pukul 06.00 – 08.00, sebelum antrean foto memanjang','06:00 – 18:00','Donasi','Kendaraan pribadi dari Denpasar, sekitar 2 jam.','Wajib memakai kain saput dan syal. Jangan memotret pemuja yang sedang beribadah dan jangan duduk di atas dinding pura.',NULL,'-',4.9,'assets/images/lempuyang.jpg',1,'aktif',0.0000000,0.0000000,'',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,'lovina-pantai',2,'Pantai Lovina','Pantai & Nelayan','Laut tenang utara Bali tempat lumba-lumba liar muncul di pagi buta.','Mei – Oktober (perairan paling tenang)','05:00 – 19:00','Gratis','Kendaraan pribadi dari Singaraja, sekitar 15 menit.','Jangan memberi makan atau menyentuh lumba-lumba. Pilih operator perahu yang dikelola nelayan lokal dan ikuti arahan mereka saat di laut.','6281455667788','0814-5566-7788',4.6,'assets/images/lovina.jpg',1,'aktif',-8.1609000,115.0267000,'https://maps.google.com/?q=-8.1609,115.0267',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,'gitgit-airterjun',2,'Air Terjun Gitgit','Alam & Hutan','Air terjun 45 meter di hutan tropis dengan jalur melewati kebun cengkeh dan kopi warga.','Pagi hari pukul 07.00 – 10.00','07:00 – 17:00','Rp 20.000','Dari Singaraja ke arah selatan, sekitar 10 km.','Jangan membuang sampah di sekitar air terjun dan gunakan tempat sampah yang disediakan. Jangan memanjat pagar pengaman yang ada.','6281566778899','0815-6677-8899',4.5,'assets/images/gitgit.jpg',1,'aktif',0.0000000,0.0000000,'',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(6,'jatiluwih-sawah',3,'Teras Sawah Jatiluwih','Sawah & Subak','600 hektar sawah subak Warisan Dunia UNESCO di kaki Gunung Batukaru.','Juni – Agustus (padi hijau merata)','06:00 – 18:00','Rp 40.000','Kendaraan pribadi dari Denpasar, sekitar 1,5 jam.','Jangan menginjak area tanaman padi dan jalur sawah yang sedang dibajak. Hormati petani yang sedang bekerja, minta izin sebelum memotret dekat.','6281677889900','0816-7788-9900',4.9,'assets/images/jatiluwih.jpg',1,'aktif',-8.3698000,115.1311000,'https://maps.google.com/?q=-8.3698,115.1311',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(7,'pura-batukaru',3,'Pura Luhur Batukaru','Pura','Pura Sad Kahyangan yang tersembunyi di hutan berkabut lereng Gunung Batukaru.','Pagi hari (kabut tipis, suasana hening)','07:00 – 17:00','Donasi','Kendaraan pribadi, area parkir tersedia di bawah.','Wajib kain saput dan syal. Jangan berbicara keras di area suci dan jangan memasuki area dalam pura tanpa didampingi.',NULL,'-',4.8,'assets/images/batukaru.jpg',1,'aktif',0.0000000,0.0000000,'',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13'),
(8,'sidemen-sawah',1,'Desa Sidemen','Desa & Pertanian','Lembah tenang di kaki Gunung Agung, dijuluki \"Ubud dua puluh tahun silam\".','Maret – November','06:00 – 18:00','Gratis','Dari Amlapura ke arah barat, sekitar 30 menit.','Tidak semua area boleh difoto. Tanyakan izin kepada pemilik rumah atau petani terlebih dahulu, terutama saat ritual sedang berlangsung.','6281788990011','0817-8899-0011',4.7,'assets/images/sidemen.jpg',1,'aktif',0.0000000,0.0000000,'',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `destinasi` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_aktivitas`
--

DROP TABLE IF EXISTS `destinasi_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_aktivitas` (
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `aktivitas_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`destinasi_id`,`aktivitas_id`),
  KEY `destinasi_aktivitas_aktivitas_id_foreign` (`aktivitas_id`),
  CONSTRAINT `destinasi_aktivitas_aktivitas_id_foreign` FOREIGN KEY (`aktivitas_id`) REFERENCES `aktivitas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `destinasi_aktivitas_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_aktivitas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_aktivitas` WRITE;
/*!40000 ALTER TABLE `destinasi_aktivitas` DISABLE KEYS */;
INSERT INTO `destinasi_aktivitas` VALUES
(1,1),
(1,2),
(1,3),
(1,4),
(1,5),
(2,2),
(2,6),
(2,7),
(2,8),
(3,2),
(3,9),
(3,10),
(3,11),
(4,5),
(4,12),
(4,13),
(4,14),
(5,2),
(5,11),
(5,15),
(5,16),
(6,2),
(6,17),
(6,18),
(6,19),
(6,20),
(7,2),
(7,9),
(7,21),
(7,22),
(8,2),
(8,11),
(8,17),
(8,19),
(8,23);
/*!40000 ALTER TABLE `destinasi_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_budaya`
--

DROP TABLE IF EXISTS `destinasi_budaya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_budaya` (
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `budaya_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`destinasi_id`,`budaya_id`),
  KEY `destinasi_budaya_budaya_id_foreign` (`budaya_id`),
  CONSTRAINT `destinasi_budaya_budaya_id_foreign` FOREIGN KEY (`budaya_id`) REFERENCES `budaya` (`id`) ON DELETE CASCADE,
  CONSTRAINT `destinasi_budaya_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_budaya`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_budaya` WRITE;
/*!40000 ALTER TABLE `destinasi_budaya` DISABLE KEYS */;
INSERT INTO `destinasi_budaya` VALUES
(1,5),
(1,6),
(2,1),
(2,2),
(3,1),
(3,2),
(4,5),
(4,6),
(5,6),
(6,6),
(7,1),
(7,2),
(8,6);
/*!40000 ALTER TABLE `destinasi_budaya` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_detail`
--

DROP TABLE IF EXISTS `destinasi_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL DEFAULT 0,
  `paragraf` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `destinasi_detail_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `destinasi_detail_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_detail`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_detail` WRITE;
/*!40000 ALTER TABLE `destinasi_detail` DISABLE KEYS */;
INSERT INTO `destinasi_detail` VALUES
(1,1,0,'Amed bukan satu pantai tunggal, melainkan rangkaian desa nelayan di sepanjang pesisir timur laut Karangasem — dari Cemeluk, Lipah, hingga Bunutan. Pasir hitam vulkaniknya berasal dari endapan Gunung Agung, memberi warna laut yang pekat dan kontras dengan perahu jukung putih yang tersusun rapi di tepian.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,1,1,'Di bawah permukaan, terumbu karang Amed termasuk yang paling sehat di Bali dan menjadi lokasi populer untuk snorkeling serta pelatihan selam. Pagi hari adalah waktu terbaik: laut tenang, cahaya lembut, dan para nelayan mulai turun ke perahu untuk melaut.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,2,0,'Dibangun tahun 1948 oleh raja terakhir Karangasem, Anak Agung Anglurah Ketut Karangasem, Tirta Gangga adalah taman air kerajaan yang memadukan gaya Bali, Tiongkok, dan Eropa. Namanya berarti \"air dari Gangga\", merujuk pada air suci sungai Gangga di India.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,2,1,'Ikon utamanya adalah kolam dengan patung dewa dan ratu naga di atas air, serta deretan batu pijakan (stepping stones) yang memungkinkan Anda berjalan di atas kolam berisi ikan koi. Air yang mengisi kolam berasal dari mata air suci di daerah itu dan dipercaya memiliki kekuatan penyembuh.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,3,0,'Pura Lempuyang Luhur berdiri di puncak Bukit Lempuyang (±1.175 mdpl) dan merupakan salah satu Sad Kahyangan — enam pura utama arah mata angin di Bali — yang dipercaya sudah ada lebih dari 1.000 tahun.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(6,3,1,'Candi Bentar di Pura Penataran Agung menjadi fenomena viral \"Gates of Heaven\" karena membingkai Gunung Agung dengan awan di kejauhan. Namun bagi umat Hindu, pura ini terutama tempat pemujaan Hyang Iswara; kunjungan wisata diharapkan menempati ruang tanpa mengganggu ritus yang sedang berlangsung.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(7,4,0,'Lovina adalah kawasan pantai di pesisir utara Buleleng yang mencakup tujuh desa, dengan pusat di Kalibukbuk. Lautnya jauh lebih tenang dibanding pantai selatan sehingga aktivitas di air nyaman dilakukan sepanjang pagi.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(8,4,1,'Atraksi utama Lovina adalah menonton lumba-lumba liar yang berkumpul di perairan ini pada pagi buta. Perahu tradisional berangkat sekitar pukul 05.30–06.00 dan menunggu lumba-lumba muncul di tengah laut. Setelah itu, snorkeling di perairan karang di sekitar Teluk Lovina juga populer.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(9,5,0,'Gitgit adalah air terjun paling terkenal di Bali utara, dengan ketinggian sekitar 45 meter. Aliran airnya jatuh ke kolam alami yang dikelilingi bebatuan dan pepohonan tropis yang rimbun.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(10,5,1,'Akses menuju air terjun melalui jalur berbatu selama 10–15 menit dari parkir. Sepanjang jalur Anda melewati kebun cengkeh dan kopi milik warga, memberi gambaran nyata kehidupan agraris desa di dataran tinggi Buleleng.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(11,6,0,'Jatiluwih berarti \"luar biasa indah\" — dan terasering sawahnya memang setara dengan namanya. Terbentang lebih dari 600 hektar di kaki Gunung Batukaru, sawah di Jatiluwih mengikuti sistem subak, sistem irigasi tradisional Bali yang telah berusia lebih dari 1.000 tahun dan diakui UNESCO sebagai Warisan Budaya Dunia pada 2012.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(12,6,1,'Saat berjalan di jalur setapak sawah, Anda akan bertemu petani yang bekerja dengan cara tradisional serta angsa-angsa yang berkeliaran. Warna pemandangan berubah menurut musim: hijau muda saat masa tanam dan kuning keemasan menjelang panen.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(13,7,0,'Pura Luhur Batukaru adalah salah satu Sad Kahyangan yang dipercaya menjaga arah barat Bali. Berbeda dengan pura-pura besar yang terbuka, pura ini tersembunyi di dalam hutan lebat di lereng Gunung Batukaru dengan arsitektur khas lereng gunung.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(14,7,1,'Kabut yang turun hampir setiap siang memberikan suasana mistis. Area pura dijaga hening oleh burung-burung hutan, memberi pengalaman ibadah dan refleksi yang sulit ditemukan di pura lain di Bali.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(15,8,0,'Sidemen adalah lembah pedesaan di kaki Gunung Agung yang sering dijuluki \"Ubud dua puluh tahun silam\" — jauh lebih tenang namun sama indahnya. Warga menggeluti pertanian sawah, tenun songket endek, dan pembuatan arak tradisional.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(16,8,1,'Berjalan menyusuri jalan desa, Anda akan melihat kegiatan sehari-hari warga: petani membajak sawah, ibu-ibu menenun di beranda, dan anak-anak bermain di sungai. Ini destinasi untuk merelaksasi diri tanpa keramaian.','2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `destinasi_detail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_gambar`
--

DROP TABLE IF EXISTS `destinasi_gambar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_gambar` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `is_utama` tinyint(1) NOT NULL DEFAULT 0,
  `kredit` varchar(255) NOT NULL DEFAULT 'Wikimedia Commons',
  `sumber_url` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `destinasi_gambar_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `destinasi_gambar_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_gambar`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_gambar` WRITE;
/*!40000 ALTER TABLE `destinasi_gambar` DISABLE KEYS */;
INSERT INTO `destinasi_gambar` VALUES
(1,1,'assets/images/amed.jpg','Pantai Amed',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,2,'assets/images/tirta-gangga.jpg','Taman Tirta Gangga',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,3,'assets/images/lempuyang.jpg','Pura Lempuyang',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,4,'assets/images/lovina.jpg','Pantai Lovina',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,5,'assets/images/gitgit.jpg','Air Terjun Gitgit',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(6,6,'assets/images/jatiluwih.jpg','Teras Sawah Jatiluwih',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(7,7,'assets/images/batukaru.jpg','Pura Luhur Batukaru',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(8,8,'assets/images/sidemen.jpg','Desa Sidemen',1,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(9,1,'assets/images/galeri/amed-1.jpg','Perahu jukung tradisional di pesisir Pantai Amed',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(10,1,'assets/images/galeri/amed-2.jpg','Terumbu karang dan biota bawah laut Amed',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(11,1,'assets/images/galeri/amed-3.jpg','Matahari terbit tenang di atas teluk Amed',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(12,2,'assets/images/galeri/tirta-gangga-1.jpg','Batu pijakan di atas kolam suci Tirta Gangga',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(13,2,'assets/images/galeri/tirta-gangga-2.jpg','Ikan mas koi berenang di mata air alami',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(14,2,'assets/images/galeri/tirta-gangga-3.jpg','Taman air kerajaan dan arsitektur peninggalan Karangasem',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(15,3,'assets/images/galeri/lempuyang-1.jpg','Candi Bentar Gerbang Surga dengan latar Gunung Agung',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(16,3,'assets/images/galeri/lempuyang-2.jpg','Tangga naga suci menuju pelataran utama pura',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(17,3,'assets/images/galeri/lempuyang-3.jpg','Suasana hening di lereng Gunung Lempuyang',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(18,4,'assets/images/galeri/lovina-1.jpg','Kawanan lumba-lumba liar melompat di laut lepas Lovina',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(19,4,'assets/images/galeri/lovina-2.jpg','Perahu cadik nelayan menyambut fajar di Bali Utara',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(20,4,'assets/images/galeri/lovina-3.jpg','Ketenangan pesisir berpasir hitam di Pantai Lovina',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(21,5,'assets/images/galeri/gitgit-1.jpg','Derasnya tirai air terjun Gitgit di tengah ngarai hijau',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(22,5,'assets/images/galeri/gitgit-2.jpg','Hutan hujan tropis rimbun di jalur setapak Gitgit',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(23,5,'assets/images/galeri/gitgit-3.jpg','Kolam alami jernih di bawah air terjun',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(24,6,'assets/images/galeri/jatiluwih-1.jpg','Lansekap hijau bertingkat warisan dunia UNESCO Jatiluwih',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(25,6,'assets/images/galeri/jatiluwih-2.jpg','Saluran irigasi tradisional Subak yang terjaga ratusan tahun',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(26,6,'assets/images/galeri/jatiluwih-3.jpg','Kabut pagi di perbukitan sawah terasering',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(27,7,'assets/images/galeri/batukaru-1.jpg','Meru bertingkat sakral dinaungi rimbun hutan lereng gunung',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(28,7,'assets/images/galeri/batukaru-2.jpg','Pelinggih batu berselimut lumut kuno yang damai',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(29,7,'assets/images/galeri/batukaru-3.jpg','Kanopi hutan lindung suci Gunung Batukaru',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(30,8,'assets/images/galeri/sidemen-1.jpg','Pemandangan lembah asri Sidemen menghadap Gunung Agung',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(31,8,'assets/images/galeri/sidemen-2.jpg','Pematang sawah alami dan sungai jernih di perbukitan',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(32,8,'assets/images/galeri/sidemen-3.jpg','Tradisi tenun kain songket dan endek khas warga desa',0,'Wikimedia Commons','','2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `destinasi_gambar` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_highlight`
--

DROP TABLE IF EXISTS `destinasi_highlight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_highlight` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL DEFAULT 0,
  `teks` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `destinasi_highlight_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `destinasi_highlight_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_highlight`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_highlight` WRITE;
/*!40000 ALTER TABLE `destinasi_highlight` DISABLE KEYS */;
INSERT INTO `destinasi_highlight` VALUES
(1,1,0,'Snorkeling dan diving dengan visibilitas yang jernih','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,1,1,'Matahari terbit dari perahu jukung bersama nelayan lokal','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,1,2,'Bukit Amed di Cemeluk untuk panorama pantai dari ketinggian','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,1,3,'Warung ikan bakar jukut masih di tepi pantai','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,2,0,'Beri makan ikan koi dari batu pijakan di kolam utama','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(6,2,1,'Pemandian suci dengan sumber air pegunungan','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(7,2,2,'Taman patung dan arca bergaya khas Karangasem','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(8,2,3,'Trekking Bukit Asah di dekatnya untuk panorama timur Bali','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(9,3,0,'Fenomena \"Gates of Heaven\" dengan latar Gunung Agung','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(10,3,1,'Jalur trek hutan ke tujuh pura di lereng (3–4 jam)','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(11,3,2,'Suasana berkabut yang misterius di pagi hari','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(12,3,3,'Pemandangan seluruh timur Bali dari puncak','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(13,4,0,'Menyaksikan lumba-lumba liar dari perahu tradisional','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(14,4,1,'Snorkeling di perairan tenang dengan karang tropis','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(15,4,2,'Pemandian air panas Banjar Tega di dekatnya','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(16,4,3,'Pantai berpasir hitam yang hening, jauh dari keramaian','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(17,5,0,'Air terjun 45 meter yang masih alami','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(18,5,1,'Trekking ringan melalui kebun cengkeh dan kopi','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(19,5,2,'Kolam alami untuk berenang (waspada saat debit tinggi)','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(20,5,3,'Warung kecil dan parkir yang dikelola warga','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(21,6,0,'Panorama terasering sawah subak seluas 600 hektar','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(22,6,1,'Jalur setapak di tengah sawah untuk jalan santai','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(23,6,2,'Warung kuliner lokal dengan pemandangan terbuka','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(24,6,3,'Wisata edukasi sistem irigasi subak','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(25,7,0,'Suasana mistis di tengah hutan berkabut','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(26,7,1,'Pura Sad Kahyangan dengan arsitektur lereng gunung','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(27,7,2,'Trekking Gunung Batukaru untuk pendaki berpengalaman','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(28,7,3,'Dekat kebun teh dan cengkeh milik warga','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(29,8,0,'Panorama sawah dengan latar Gunung Agung','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(30,8,1,'Wisata tenun endek dan songket kerja tangan warga','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(31,8,2,'Trekking ringan lembah dan desa','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(32,8,3,'Kuliner khas Karangasem','2026-11-18 16:38:14','2026-11-18 16:38:14');
/*!40000 ALTER TABLE `destinasi_highlight` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `kalender`
--

DROP TABLE IF EXISTS `kalender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kalender` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `tanggal_teks` varchar(255) NOT NULL DEFAULT '',
  `keterangan` text NOT NULL,
  `saran` text NOT NULL,
  `sejarah` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kalender`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kalender` WRITE;
/*!40000 ALTER TABLE `kalender` DISABLE KEYS */;
INSERT INTO `kalender` VALUES
(1,'Nyepi','Menurut kalender Saka (biasanya Maret–April)','Hari sunyi, seluruh aktivitas di Bali berhenti 24 jam.','Tetap di akomodasi, lampu redup, jangan beraktivitas di luar.','Hari Raya Nyepi menandai pergantian Tahun Baru Saka Hindu yang dimulai sejak tahun 78 Masehi, merujuk pada rekonsiliasi damai antar-suku bangsa di India kuno oleh Raja Kaniska I. Di Bali, Nyepi bertransformasi menjadi momen pemurnian kosmos (Bhuana Agung) dan batin manusia (Bhuana Alit) melalui Catur Brata Penyepian: Amati Geni (tidak menyalakan api/cahaya), Amati Karya (tidak bekerja), Amati Lelungan (tidak bepergian), dan Amati Lelanguan (tidak bersenang-senang). Sehari sebelum Nyepi, diadakan upacara Tawur Kesanga dan pawai Ogoh-ogoh sebagai simbol menetralisir sifat-sifat negatif (Bhuta Kala) agar keharmonisan semesta kembali suci.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,'Galungan','Setiap 210 hari (kalender Pawukon)','Perayaan kemenangan dharma, penjor dipasang di depan rumah.','Pura ramai, warga memakai busana adat. Foto boleh dengan penuh hormat.','Hari Raya Galungan diperingati untuk merayakan kemenangan kebajikan (Dharma) melawan kejahatan (Adharma). Tradisi ini pertama kali dirayakan secara resmi pada Purnama Kapat tahun 882 Masehi semasa pemerintahan Raja Sri Jayakasunu. Konon raja menerima wangsit suci dari Dewi Durga untuk mengadakan perayaan puja bhakti kepada Hyang Widhi dan para leluhur agar wabah malapetaka reda. Penjor megah yang terbuat dari bambu berhiaskan janur, padi, dan hasil bumi dipasang di depan setiap rumah sebagai lambang Gunung Agung dan naga kemakmuran Basuki-Ananta Boga.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,'Kuningan','10 hari setelah Galungan','Hari para leluhur kembali ke surga.','Suasana mirip Galungan namun lebih tenang. Waktu terbaik melihat ritual keluarga.','Hari Raya Kuningan jatuh tepat 10 hari setelah Galungan, menandai penutupan rangkaian perayaan kemenangan Dharma. Menurut teologi Hindu Bali, pada hari ini para Dewa dan roh suci leluhur yang sebelumnya turun mengunjungi sanak keluarga saat Galungan akan kembali berpulang ke Swargaloka. Ciri khas upacara Kuningan adalah persembahan nasi kuning (simbol kemakmuran dan rasa syukur) serta Tamiang dan Kolem yang dipasang di pelinggih sebagai tameng pertahanan spiritual diri dari marabahaya.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,'Saraswati','Setiap 210 hari','Hari ilmu pengetahuan, buku dan lontar disembahyakan.','Sekolah dan perpustakaan mungkin libur. Hormati ritual yang berlangsung.','Hari Raya Saraswati dirayakan setiap hari Saniscara Umanis Wuku Watugunung untuk memuja Sang Hyang Saraswati, dewi penguasa ilmu pengetahuan, sastra, dan kebijaksanaan suci. Filosofi Saraswati mengajarkan bahwa pengetahuan adalah senjata sejati manusia untuk mengatasi kebodohan (Awidya) dan mencapai pencerahan hidup. Pada hari ini, kitab suci Weda, lontar kuno, dan buku-buku disucikan dengan canang sari dan wewangian, sementara umat berpantang membaca dan menulis sampai matahari terbit keesokan harinya saat Banyu Pinaruh (mandi suci penyucian diri di mata air).','2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `kalender` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_11_18_115501_create_wilayah_table',1),
(5,'2026_11_18_135610_add_sar_i_fields_to_users_table',1),
(6,'2026_11_18_200940_create_aktivitas_table',1),
(7,'2026_11_18_220124_create_destinasi_table',1),
(8,'2026_11_19_075957_create_budaya_table',1),
(9,'2026_11_19_075958_create_kalender_table',1),
(10,'2026_11_19_075959_create_destinasi_detail_table',1),
(11,'2026_11_19_080000_create_destinasi_gambar_table',1),
(12,'2026_11_19_080001_create_destinasi_highlight_table',1),
(13,'2026_11_19_080002_create_destinasi_aktivitas_table',1),
(14,'2026_11_19_080003_create_destinasi_budaya_table',1),
(15,'2026_11_19_080004_create_ulasan_table',1),
(16,'2026_11_19_080005_create_statistik_kunjungan_table',1),
(17,'2026_11_19_080006_create_pengaturan_table',1),
(18,'2026_11_19_080007_create_bookmark_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pengaturan`
--

DROP TABLE IF EXISTS `pengaturan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pengaturan` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengaturan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pengaturan` WRITE;
/*!40000 ALTER TABLE `pengaturan` DISABLE KEYS */;
INSERT INTO `pengaturan` VALUES
('nama_situs','SARI','2026-11-18 16:38:14','2026-11-18 16:38:14'),
('tagline','Inti seni, adat, dan rasa Bali untuk wisatawan bijak','2026-11-18 16:38:14','2026-11-18 16:38:14'),
('whatsapp_pusat','6281234567890','2026-11-18 16:38:14','2026-11-18 16:38:14');
/*!40000 ALTER TABLE `pengaturan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `statistik_kunjungan`
--

DROP TABLE IF EXISTS `statistik_kunjungan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistik_kunjungan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_statistik_destinasi_tanggal` (`destinasi_id`,`tanggal`),
  CONSTRAINT `statistik_kunjungan_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistik_kunjungan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `statistik_kunjungan` WRITE;
/*!40000 ALTER TABLE `statistik_kunjungan` DISABLE KEYS */;
INSERT INTO `statistik_kunjungan` VALUES
(1,6,'2026-11-14',3,'2026-11-18 16:38:14','2026-11-18 16:38:14'),
(2,1,'2026-11-14',39,'2026-11-18 16:38:14','2026-11-18 16:38:14'),
(3,2,'2026-11-14',2,'2026-11-18 16:38:14','2026-11-18 16:38:14'),
(4,7,'2026-11-14',1,'2026-11-18 16:38:14','2026-11-18 16:38:14'),
(5,4,'2026-11-14',1,'2026-11-18 16:38:14','2026-11-18 16:38:14'),
(6,3,'2026-11-14',1,'2026-11-18 16:38:14','2026-11-18 16:38:14');
/*!40000 ALTER TABLE `statistik_kunjungan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ulasan`
--

DROP TABLE IF EXISTS `ulasan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ulasan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `nama_pengunjung` varchar(255) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `komentar` text NOT NULL,
  `status` enum('pending','disetujui','ditolak') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ulasan_destinasi` (`destinasi_id`,`status`),
  CONSTRAINT `ulasan_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulasan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ulasan` WRITE;
/*!40000 ALTER TABLE `ulasan` DISABLE KEYS */;
INSERT INTO `ulasan` VALUES
(1,1,'I Wayan Sukadana',5,'Suasana pagi hari sangat hening, air laut jernih sekali sampai terumbu karang kelihatan dari perahu jukung nelayan lokal.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(2,1,'Sarah Jenkins',5,'Amazing snorkeling spot away from the crowded south. Local boatmen were incredibly friendly and respectful.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(3,2,'Ni Kadek Ayu',5,'Airnya segar dan sangat terawat. Jangan lupa bawa pakan ikan untuk memberi makan ikan koi besar di kolam utama.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(4,2,'Michael Schmidt',4,'A truly peaceful royal garden. Visiting early morning before 9 AM gave us the whole place to ourselves.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(5,3,'Ketut Dharma',5,'Tempat ibadah yang sangat disakralkan. Pemandangan Gunung Agung dari Gerbang Surga saat cuaca cerah betul-betul magis.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(6,3,'Elena Rostova',5,'Breathtaking spiritual site. Make sure to wear respectful temple attire (sarong provided). The energy here is sublime.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(7,4,'Putu Artha',5,'Melihat lumba-lumba berenang bebas di habitat aslinya adalah pengalaman tak terlupakan untuk anak-anak.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(8,4,'Liam O\'Connor',4,'Gentle morning boat ride with dolphins breaching near sunrise. Calm waters and authentic local captains.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(9,5,'Gede Wira',5,'Air terjun tertinggi dan udara di sekitarnya sangat sejuk. Jalur tangga menurun cukup menguras tenaga tapi terbayar lunas.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(10,5,'Claire Dubois',5,'Lush tropical trail filled with clove and coffee trees. The waterfall mist is so refreshing after the hike.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(11,6,'Made Sudarma',5,'Sistem irigasi Subak di sini adalah mahakarya leluhur. Jalan kaki di jalur trekking sawah sangat menenangkan pikiran.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(12,6,'David Miller',5,'The vast green rice terraces seem to go on forever. Unforgettable UNESCO heritage without tourist circus.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(13,7,'Wayan Sujana',5,'Pura di tengah hutan belantara kaki gunung. Hawanya sejuk berkabut, sangat hening untuk menenangkan batin dan berdoa.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(14,7,'Sophie Martin',5,'Deeply spiritual and untouched temple surrounded by primordial rainforest. Far more meaningful than crowded tourist spots.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(15,8,'Nyoman Kartika',5,'Desa yang masih sangat asri dengan panorama lembah dan kain tenun tradisional. Penginapan lokalnya ramah dan otentik.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(16,8,'Tom van Dijk',5,'Sidemen reminds me of Bali decades ago. Peaceful valley walks, friendly villagers, and stunning vistas of Mount Agung.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(17,1,'Budi Santoso',5,'Snorkeling di Amed sangat tenang, banyak terumbu karang indah dan warga lokal sangat ramah.','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(18,1,'dimas',5,'bagus sekali','ditolak','2026-11-18 16:38:14','2026-11-18 16:38:14'),
(19,1,'Test Reviewer',5,'Test review comment - great place!','disetujui','2026-11-18 16:38:14','2026-11-18 16:38:14');
/*!40000 ALTER TABLE `ulasan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `bio` text NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Test User','test@example.com','2026-11-18 16:38:12','$2y$12$.dKl9Bli2L3Px1OBu6ex..AA0UpBr4pqlvfJKExEaR6mHTSbV/eSq','admin','','','3t1rosXOet','2026-11-18 16:38:12','2026-11-18 16:38:13'),
(2,'Administrator SARI','admin@sari-bali.id','2026-11-18 16:38:13','$2y$12$K2IGTG2yg.uNU3i66pJiveqLhnzZvzPiV.zVV.SoXi4YTkID5qqAW','admin','','',NULL,'2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `wilayah`
--

DROP TABLE IF EXISTS `wilayah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wilayah` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wilayah_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wilayah`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `wilayah` WRITE;
/*!40000 ALTER TABLE `wilayah` DISABLE KEYS */;
INSERT INTO `wilayah` VALUES
(1,'karangasem','Karangasem','Gunung, pura tua, dan pantai tenang di timur Bali.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(2,'buleleng','Buleleng','Pantai hitam, lumba-lumba, dan air terjun di utara Bali.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(3,'tabanan','Tabanan','Teras sawah UNESCO, sistem subak, dan pura di lereng gunung.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(4,'klungkung','Klungkung','Pusat kerajaan klasik, seni, dan gerbang menuju Nusa Penida.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(5,'bangli','Bangli','Danau Batur, udara sejuk pegunungan, dan adat yang masih hidup.','2026-11-18 16:38:13','2026-11-18 16:38:13'),
(6,'gianyar','Gianyar','Jantung seni dan kerajinan Bali dengan pasar-pasar tradisional.','2026-11-18 16:38:13','2026-11-18 16:38:13');
/*!40000 ALTER TABLE `wilayah` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-19  8:52:29
