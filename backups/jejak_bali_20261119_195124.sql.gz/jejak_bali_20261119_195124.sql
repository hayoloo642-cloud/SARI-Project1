/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: jejak_bali
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `aktivitas`
--

DROP TABLE IF EXISTS `aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aktivitas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aktivitas_nama_unique` (`nama`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aktivitas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `aktivitas` WRITE;
/*!40000 ALTER TABLE `aktivitas` DISABLE KEYS */;
INSERT INTO `aktivitas` VALUES
(1,'Diving','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(2,'Fotografi','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(3,'Kuliner ikan bakar','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(4,'Matahari terbit','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(5,'Snorkeling','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(6,'Beri makan koi','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(7,'Pemandian suci','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(8,'Trekking ringan','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(9,'Ibadah','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(10,'Meditasi','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(11,'Trekking','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(12,'Pemandian air panas','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(13,'Perahu nelayan','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(14,'Tontonan lumba-lumba','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(15,'Berenang','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(16,'Wisata kebun','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(17,'Bersepeda','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(18,'Edukasi subak','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(19,'Kuliner','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(20,'Trekking sawah','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(21,'Kuliner desa','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(22,'Trekking gunung','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(23,'Tenun & kerajinan','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(24,'Renang','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(25,'Trekking bambu','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(26,'Belajar adat Bali Aga','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(27,'Kuliner lokal','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(28,'Beli kerajinan','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(29,'Berenang kolam alami','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(30,'Edukasi alam','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(31,'Jalan pagi','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(32,'Kano','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(33,'Edukasi mangrove','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(34,'Melukat (pemandian suci)','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(35,'Sejarah & arkeologi','2026-11-19 03:47:44','2026-11-19 03:47:44');
/*!40000 ALTER TABLE `aktivitas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmark` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_bookmark_user_destinasi` (`user_id`,`destinasi_id`),
  KEY `bookmark_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `bookmark_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookmark_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmark`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bookmark` WRITE;
/*!40000 ALTER TABLE `bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookmark` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `budaya`
--

DROP TABLE IF EXISTS `budaya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `budaya` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `ringkas` text NOT NULL,
  `detail` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `budaya_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budaya`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `budaya` WRITE;
/*!40000 ALTER TABLE `budaya` DISABLE KEYS */;
INSERT INTO `budaya` VALUES
(1,'busana-pura','Busana Masuk Pura','Kain saput dan syal untuk wanita, kain panjang untuk pria.','Kain saput dipakai di pinggang dan syal menutup bahu. Hindari celana pendek dan rok mini di area suci. Jika tidak membawa, biasanya dapat dipinjam di pintu masuk pura.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(2,'canang-sari','Canang Sari','Persembahan kecil dari janur dan bunga di jalanan dan depan rumah.','Jangan menginjak canang yang tersebar di jalanan. Jika ingin memotret, minta izin terlebih dahulu kepada pemilik rumah atau penjaga area.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(3,'nyepi','Hari Nyepi','Hari suci Tahun Baru Saka, seluruh aktivitas dihentikan 24 jam.','Selama Catur Brata Penyepian: api mati, lampu redup, tidak keluar rumah, tidak bekerja, dan tidak bersuka ria. Wisatawan di hotel juga diharapkan mematuhi.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(4,'basa-bali','Frasa Bahasa Bali Dasar','Kata sederhana untuk menunjukkan hormat kepada warga lokal.','Om Swastiastu (salam hormat), Matur Suksma (terima kasih), Bli (sapaan laki-laki), Mbok (sapaan perempuan).','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(5,'adat-laut','Adat Laut & Nelayan','Hormati laut dan kehidupan nelayan di pesisir Bali.','Jangan membuang sampah ke laut dan jangan menyentuh terumbu karang saat berenang. Jika akan naik perahu, ikuti arahan nelayan lokal.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(6,'pantang-larang-desa','Pantang Larang Desa','Beberapa area desa memiliki larangan khusus pada waktu tertentu.','Perhatikan papan pengumuman di pintu desa. Jika ada area yang dilarang untuk difoto, hargai dan jangan memaksa mengambil gambar.','2026-11-19 03:49:50','2026-11-19 03:49:50');
/*!40000 ALTER TABLE `budaya` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi`
--

DROP TABLE IF EXISTS `destinasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `wilayah_id` bigint(20) unsigned NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL DEFAULT '',
  `deskripsi` text NOT NULL,
  `waktu_terbaik` varchar(255) NOT NULL DEFAULT '',
  `jam_buka` varchar(255) NOT NULL DEFAULT '',
  `tarif` varchar(255) NOT NULL DEFAULT '',
  `cara_masuk` text NOT NULL,
  `etika` text NOT NULL,
  `whatsapp` varchar(255) DEFAULT NULL,
  `kontak` varchar(255) NOT NULL DEFAULT '-',
  `rating_awal` decimal(3,1) NOT NULL DEFAULT 4.5,
  `gambar` varchar(255) NOT NULL DEFAULT '',
  `is_unggulan` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('draft','aktif') NOT NULL DEFAULT 'aktif',
  `latitude` decimal(10,7) NOT NULL DEFAULT 0.0000000,
  `longitude` decimal(10,7) NOT NULL DEFAULT 0.0000000,
  `maps_url` varchar(255) NOT NULL DEFAULT '',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `destinasi_slug_unique` (`slug`),
  KEY `destinasi_wilayah_id_foreign` (`wilayah_id`),
  KEY `destinasi_user_id_foreign` (`user_id`),
  FULLTEXT KEY `destinasi_nama_deskripsi_fulltext` (`nama`,`deskripsi`),
  CONSTRAINT `destinasi_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `destinasi_wilayah_id_foreign` FOREIGN KEY (`wilayah_id`) REFERENCES `wilayah` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi` WRITE;
/*!40000 ALTER TABLE `destinasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinasi` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_aktivitas`
--

DROP TABLE IF EXISTS `destinasi_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_aktivitas` (
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `aktivitas_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`destinasi_id`,`aktivitas_id`),
  KEY `destinasi_aktivitas_aktivitas_id_foreign` (`aktivitas_id`),
  CONSTRAINT `destinasi_aktivitas_aktivitas_id_foreign` FOREIGN KEY (`aktivitas_id`) REFERENCES `aktivitas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `destinasi_aktivitas_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_aktivitas`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_aktivitas` WRITE;
/*!40000 ALTER TABLE `destinasi_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinasi_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_budaya`
--

DROP TABLE IF EXISTS `destinasi_budaya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_budaya` (
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `budaya_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`destinasi_id`,`budaya_id`),
  KEY `destinasi_budaya_budaya_id_foreign` (`budaya_id`),
  CONSTRAINT `destinasi_budaya_budaya_id_foreign` FOREIGN KEY (`budaya_id`) REFERENCES `budaya` (`id`) ON DELETE CASCADE,
  CONSTRAINT `destinasi_budaya_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_budaya`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_budaya` WRITE;
/*!40000 ALTER TABLE `destinasi_budaya` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinasi_budaya` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_detail`
--

DROP TABLE IF EXISTS `destinasi_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL DEFAULT 0,
  `paragraf` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `destinasi_detail_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `destinasi_detail_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_detail`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_detail` WRITE;
/*!40000 ALTER TABLE `destinasi_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinasi_detail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_gambar`
--

DROP TABLE IF EXISTS `destinasi_gambar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_gambar` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `is_utama` tinyint(1) NOT NULL DEFAULT 0,
  `kredit` varchar(255) NOT NULL DEFAULT 'Wikimedia Commons',
  `sumber_url` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `destinasi_gambar_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `destinasi_gambar_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_gambar`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_gambar` WRITE;
/*!40000 ALTER TABLE `destinasi_gambar` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinasi_gambar` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `destinasi_highlight`
--

DROP TABLE IF EXISTS `destinasi_highlight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinasi_highlight` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `urutan` int(10) unsigned NOT NULL DEFAULT 0,
  `teks` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `destinasi_highlight_destinasi_id_foreign` (`destinasi_id`),
  CONSTRAINT `destinasi_highlight_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinasi_highlight`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `destinasi_highlight` WRITE;
/*!40000 ALTER TABLE `destinasi_highlight` DISABLE KEYS */;
/*!40000 ALTER TABLE `destinasi_highlight` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `kalender`
--

DROP TABLE IF EXISTS `kalender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kalender` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `tanggal_teks` varchar(255) NOT NULL DEFAULT '',
  `keterangan` text NOT NULL,
  `saran` text NOT NULL,
  `sejarah` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kalender`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kalender` WRITE;
/*!40000 ALTER TABLE `kalender` DISABLE KEYS */;
INSERT INTO `kalender` VALUES
(1,'Nyepi','Menurut kalender Saka (biasanya Maret–April)','Hari sunyi, seluruh aktivitas di Bali berhenti 24 jam.','Tetap di akomodasi, lampu redup, jangan beraktivitas di luar.','Hari Raya Nyepi menandai pergantian Tahun Baru Saka Hindu yang dimulai sejak tahun 78 Masehi, merujuk pada rekonsiliasi damai antar-suku bangsa di India kuno oleh Raja Kaniska I. Di Bali, Nyepi bertransformasi menjadi momen pemurnian kosmos (Bhuana Agung) dan batin manusia (Bhuana Alit) melalui Catur Brata Penyepian: Amati Geni (tidak menyalakan api/cahaya), Amati Karya (tidak bekerja), Amati Lelungan (tidak bepergian), dan Amati Lelanguan (tidak bersenang-senang). Sehari sebelum Nyepi, diadakan upacara Tawur Kesanga dan pawai Ogoh-ogoh sebagai simbol menetralisir sifat-sifat negatif (Bhuta Kala) agar keharmonisan semesta kembali suci.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(2,'Galungan','Setiap 210 hari (kalender Pawukon)','Perayaan kemenangan dharma, penjor dipasang di depan rumah.','Pura ramai, warga memakai busana adat. Foto boleh dengan penuh hormat.','Hari Raya Galungan diperingati untuk merayakan kemenangan kebajikan (Dharma) melawan kejahatan (Adharma). Tradisi ini pertama kali dirayakan secara resmi pada Purnama Kapat tahun 882 Masehi semasa pemerintahan Raja Sri Jayakasunu. Konon raja menerima wangsit suci dari Dewi Durga untuk mengadakan perayaan puja bhakti kepada Hyang Widhi dan para leluhur agar wabah malapetaka reda. Penjor megah yang terbuat dari bambu berhiaskan janur, padi, dan hasil bumi dipasang di depan setiap rumah sebagai lambang Gunung Agung dan naga kemakmuran Basuki-Ananta Boga.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(3,'Kuningan','10 hari setelah Galungan','Hari para leluhur kembali ke surga.','Suasana mirip Galungan namun lebih tenang. Waktu terbaik melihat ritual keluarga.','Hari Raya Kuningan jatuh tepat 10 hari setelah Galungan, menandai penutupan rangkaian perayaan kemenangan Dharma. Menurut teologi Hindu Bali, pada hari ini para Dewa dan roh suci leluhur yang sebelumnya turun mengunjungi sanak keluarga saat Galungan akan kembali berpulang ke Swargaloka. Ciri khas upacara Kuningan adalah persembahan nasi kuning (simbol kemakmuran dan rasa syukur) serta Tamiang dan Kolem yang dipasang di pelinggih sebagai tameng pertahanan spiritual diri dari marabahaya.','2026-11-19 03:49:50','2026-11-19 03:49:50'),
(4,'Saraswati','Setiap 210 hari','Hari ilmu pengetahuan, buku dan lontar disembahyakan.','Sekolah dan perpustakaan mungkin libur. Hormati ritual yang berlangsung.','Hari Raya Saraswati dirayakan setiap hari Saniscara Umanis Wuku Watugunung untuk memuja Sang Hyang Saraswati, dewi penguasa ilmu pengetahuan, sastra, dan kebijaksanaan suci. Filosofi Saraswati mengajarkan bahwa pengetahuan adalah senjata sejati manusia untuk mengatasi kebodohan (Awidya) dan mencapai pencerahan hidup. Pada hari ini, kitab suci Weda, lontar kuno, dan buku-buku disucikan dengan canang sari dan wewangian, sementara umat berpantang membaca dan menulis sampai matahari terbit keesokan harinya saat Banyu Pinaruh (mandi suci penyucian diri di mata air).','2026-11-19 03:49:50','2026-11-19 03:49:50');
/*!40000 ALTER TABLE `kalender` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_11_18_115501_create_wilayah_table',1),
(5,'2026_11_18_135610_add_sar_i_fields_to_users_table',1),
(6,'2026_11_18_200940_create_aktivitas_table',1),
(7,'2026_11_18_220124_create_destinasi_table',1),
(8,'2026_11_19_075957_create_budaya_table',1),
(9,'2026_11_19_075958_create_kalender_table',1),
(10,'2026_11_19_075959_create_destinasi_detail_table',1),
(11,'2026_11_19_080000_create_destinasi_gambar_table',1),
(12,'2026_11_19_080001_create_destinasi_highlight_table',1),
(13,'2026_11_19_080002_create_destinasi_aktivitas_table',1),
(14,'2026_11_19_080003_create_destinasi_budaya_table',1),
(15,'2026_11_19_080004_create_ulasan_table',1),
(16,'2026_11_19_080005_create_statistik_kunjungan_table',1),
(17,'2026_11_19_080006_create_pengaturan_table',1),
(18,'2026_11_19_080007_create_bookmark_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pengaturan`
--

DROP TABLE IF EXISTS `pengaturan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pengaturan` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengaturan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pengaturan` WRITE;
/*!40000 ALTER TABLE `pengaturan` DISABLE KEYS */;
/*!40000 ALTER TABLE `pengaturan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `statistik_kunjungan`
--

DROP TABLE IF EXISTS `statistik_kunjungan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statistik_kunjungan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_statistik_destinasi_tanggal` (`destinasi_id`,`tanggal`),
  CONSTRAINT `statistik_kunjungan_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistik_kunjungan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `statistik_kunjungan` WRITE;
/*!40000 ALTER TABLE `statistik_kunjungan` DISABLE KEYS */;
/*!40000 ALTER TABLE `statistik_kunjungan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ulasan`
--

DROP TABLE IF EXISTS `ulasan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ulasan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `destinasi_id` bigint(20) unsigned NOT NULL,
  `nama_pengunjung` varchar(255) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `komentar` text NOT NULL,
  `status` enum('pending','disetujui','ditolak') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ulasan_destinasi` (`destinasi_id`,`status`),
  CONSTRAINT `ulasan_destinasi_id_foreign` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulasan`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ulasan` WRITE;
/*!40000 ALTER TABLE `ulasan` DISABLE KEYS */;
/*!40000 ALTER TABLE `ulasan` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `bio` text NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Test User','test@example.com','2026-11-19 03:47:43','$2y$12$XbkbMcEaXWzQrYsSCBvopuc69Yj9UmdfG4TMuH/j99lSADnwIq0KC','admin','','','YHfGsX4RS7','2026-11-19 03:47:44','2026-11-19 03:49:50'),
(3,'Administrator SARI','admin@sari-bali.id','2026-11-19 03:49:50','$2y$12$q4pgqvVt0kqdUHYoRyZ3TOfdK5HzHuZYXm4ma5NzeXTOEeDDDi2PC','admin','','',NULL,'2026-11-19 03:49:50','2026-11-19 03:49:50');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `wilayah`
--

DROP TABLE IF EXISTS `wilayah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wilayah` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wilayah_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wilayah`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `wilayah` WRITE;
/*!40000 ALTER TABLE `wilayah` DISABLE KEYS */;
INSERT INTO `wilayah` VALUES
(1,'karangasem','Karangasem','Gunung, pura tua, dan pantai tenang di timur Bali.','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(2,'buleleng','Buleleng','Pantai hitam, lumba-lumba, dan air terjun di utara Bali.','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(3,'tabanan','Tabanan','Teras sawah UNESCO, sistem subak, dan pura di lereng gunung.','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(4,'klungkung','Klungkung','Pusat kerajaan klasik, seni, dan gerbang menuju Nusa Penida.','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(5,'bangli','Bangli','Danau Batur, udara sejuk pegunungan, dan adat yang masih hidup.','2026-11-19 03:47:44','2026-11-19 03:47:44'),
(6,'gianyar','Gianyar','Jantung seni dan kerajinan Bali dengan pasar-pasar tradisional.','2026-11-19 03:47:44','2026-11-19 03:47:44');
/*!40000 ALTER TABLE `wilayah` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-19 19:51:25
